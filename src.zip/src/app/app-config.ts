
import _DB from '../assets/_db.json';
export const GLOBAL = { _DB }